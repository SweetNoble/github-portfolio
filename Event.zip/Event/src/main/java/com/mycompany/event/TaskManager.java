/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.event;
import java.util.*;

// manages all tasks using a linked map to preserve insertion order
public class TaskManager {
    private Map<String, Task> tasks = new LinkedHashMap<>();

    // add task with no category (gui use)
    public void addTask(String name){
        tasks.putIfAbsent(name, new Task(name, "")); 
    }
    public void addTask(String name, String category){ 
        tasks.putIfAbsent(name, new Task(name, category)); 
    }

    public Task    getTask(String name){ 
        return tasks.get(name); }
    public boolean hasTask(String name){ 
        return tasks.containsKey(name); }
    public boolean containsTask(String name){ 
        return tasks.containsKey(name); }
    public Collection<Task> getAllTasks(){ 
        return tasks.values(); 
    }

    // removes task; returns false if not found
    public boolean deleteTask(String name) {
        if (!tasks.containsKey(name)) return false;
        tasks.remove(name);
        return true;
    }

    public int size(){
        return tasks.size(); 
    }
}
