/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.event;
import java.awt.CardLayout;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;
 
public class FunctionalitiesGUI extends javax.swing.JFrame {

    private TaskManager manager = new TaskManager();
    private Graph       graph   = new Graph();
    private String      eventTitle = "";
 
    // list models bound to each JList
    private DefaultListModel<String> addSubModel  = new DefaultListModel<>();  // Add Task subtask list
    private DefaultListModel<String> taskDepModel = new DefaultListModel<>();  // Task dependency list
    private DefaultListModel<String> subDepModel  = new DefaultListModel<>();  // Subtask dependency list
    private DefaultListModel<String> viewModel    = new DefaultListModel<>();  // View Task list
    private DefaultListModel<String> editSubModel = new DefaultListModel<>();  // Edit subtask list
 
    // tracks which task is currently being edited
    private String editingTask = "";
 
    // receives event title from WelcomeGUI, sets up ui and wires list models
    public FunctionalitiesGUI(String eventTitle) {
        this.eventTitle = eventTitle;
        initComponents();

        // fix missing borders

        TaskDependencyBtn.setBorder(null);
        SubtaskDependencyBtn.setBorder(null);
        AddTaskDependencyBtn.setBorder(null);
        DeleteTaskDependencyBtn.setBorder(null);
        AddSubtaskDependencyBtn.setBorder(null);
        DeleteSubtaskDependencyBtn.setBorder(null);
        EditBtn.setBorder(null);
        DeleteBtn.setBorder(null);
        EditAddSubBtn.setBorder(null);
        EditDeleteSubBtn.setBorder(null);
        EditSaveTaskBtn.setBorder(null);
        
        // also fix focus painted on ALL buttons while we're here
        AddBtn.setFocusPainted(false);
        DependencyBtn.setFocusPainted(false);
        ViewBtn.setFocusPainted(false);
        ScheduleBtn.setFocusPainted(false);
        ExitBtn.setFocusPainted(false);
        AddSubBtn.setFocusPainted(false);
        SaveTaskBtn.setFocusPainted(false);
        TaskDependencyBtn.setFocusPainted(false);
        SubtaskDependencyBtn.setFocusPainted(false);
        AddTaskDependencyBtn.setFocusPainted(false);
        DeleteTaskDependencyBtn.setFocusPainted(false);
        AddSubtaskDependencyBtn.setFocusPainted(false);
        DeleteSubtaskDependencyBtn.setFocusPainted(false);
        EditBtn.setFocusPainted(false);
        DeleteBtn.setFocusPainted(false);
        EditAddSubBtn.setFocusPainted(false);
        EditDeleteSubBtn.setFocusPainted(false);
        EditSaveTaskBtn.setFocusPainted(false);

        // wire live models to the JLists
        jList1.setModel(addSubModel);
        jList2.setModel(taskDepModel);
        jList3.setModel(subDepModel);
        jList4.setModel(viewModel);
        jList5.setModel(editSubModel);

        setTitle("EventFlow - " + eventTitle);
        setLocationRelativeTo(null);
    }
    // returns subtasks of a task sorted by their dependency order using kahn's algorithm
    // throws RuntimeException if a circular dependency is detected
    private java.util.List<String> getOrderedSubtasks(String taskName, java.util.List<String> subtasks) {
         // build local dep map and in-degree for subtasks of this task
        java.util.Map<String, java.util.List<String>> depMap = new java.util.LinkedHashMap<>();
        java.util.Map<String, Integer> inDeg = new java.util.LinkedHashMap<>();

        for (String sub : subtasks) {
            depMap.put(sub, new java.util.ArrayList<>());
            inDeg.put(sub, 0);
        }

        // read subtask deps from graph raw list
        for (String raw : graph.getSubtaskDepRawList()) {
            int colon = raw.indexOf("::");
            int pipe  = raw.indexOf("||");
            if (colon < 0 || pipe < 0) continue;

                String pA  = raw.substring(0, colon);
                String sA  = raw.substring(colon + 2, pipe);
                String rest = raw.substring(pipe + 2);

            int bracket = rest.lastIndexOf(" [");
            if (bracket < 0) continue;
                String sB  = rest.substring(0, bracket);
                String pB  = rest.substring(bracket + 2, rest.length() - 1);

            // skip deps not belonging to this task
            if (!pA.equals(taskName) || !pB.equals(taskName)) continue;
                if (!depMap.containsKey(sA) || !depMap.containsKey(sB)) continue;

            // sA depends on sB → sB must come first → edge sB→sA
            depMap.get(sB).add(sA);
            inDeg.put(sA, inDeg.get(sA) + 1);
        }

    // kahn's: start with zero in-degree subtasks
    java.util.Queue<String> queue = new java.util.LinkedList<>();
    for (String sub : subtasks) {
        if (inDeg.get(sub) == 0) queue.add(sub);
    }

    java.util.List<String> result = new java.util.ArrayList<>();
    while (!queue.isEmpty()) {
        String cur = queue.poll();
        result.add(cur);
        for (String next : depMap.get(cur)) {
            inDeg.put(next, inDeg.get(next) - 1);
            if (inDeg.get(next) == 0) queue.add(next);
        }
    }

    // cycle detected if not all subtasks were processed
    if (result.size() != subtasks.size()) {
        java.util.List<String> cycle = new java.util.ArrayList<>();
        for (String s : inDeg.keySet())
            if (inDeg.get(s) > 0) cycle.add(s);
        throw new RuntimeException(
            "Circular dependency detected " + taskName 
            + "\nSubtasks involved: " + String.join(", ", cycle));
    }
    return result;
}
    public FunctionalitiesGUI() {
        initComponents();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        icon = new javax.swing.JLabel();
        AddBtn = new javax.swing.JButton();
        DependencyBtn = new javax.swing.JButton();
        ViewBtn = new javax.swing.JButton();
        ScheduleBtn = new javax.swing.JButton();
        ExitBtn = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        AddPanel = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        TaskNameField = new javax.swing.JTextField();
        SubNameField = new javax.swing.JTextField();
        AddSubBtn = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jList1 = new javax.swing.JList<>();
        SaveTaskBtn = new javax.swing.JButton();
        DependencyPanel = new javax.swing.JPanel();
        ChooseDependencyPanel = new javax.swing.JPanel();
        TaskDependencyBtn = new javax.swing.JButton();
        SubtaskDependencyBtn = new javax.swing.JButton();
        TaskDependencyPanel = new javax.swing.JPanel();
        TaskBox1 = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        TaskBox2 = new javax.swing.JComboBox<>();
        AddTaskDependencyBtn = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jList2 = new javax.swing.JList<>();
        DeleteTaskDependencyBtn = new javax.swing.JButton();
        SubtaskDependencyPanel = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        PickTaskBox = new javax.swing.JComboBox<>();
        SubtaskBox2 = new javax.swing.JComboBox<>();
        SubtaskBox1 = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jList3 = new javax.swing.JList<>();
        AddSubtaskDependencyBtn = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        DeleteSubtaskDependencyBtn = new javax.swing.JButton();
        ViewPanel = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        jList4 = new javax.swing.JList<>();
        EditBtn = new javax.swing.JButton();
        DeleteBtn = new javax.swing.JButton();
        EditPanel = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        EditTaskField = new javax.swing.JTextField();
        EditSubtaskField = new javax.swing.JTextField();
        EditAddSubBtn = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        jList5 = new javax.swing.JList<>();
        EditDeleteSubBtn = new javax.swing.JButton();
        EditSaveTaskBtn = new javax.swing.JButton();
        SchedulePanel = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        jScrollPane6 = new javax.swing.JScrollPane();
        ScheduleArea = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(153, 204, 0));

        icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/event/Logo.png.png"))); // NOI18N

        AddBtn.setBackground(new java.awt.Color(102, 153, 0));
        AddBtn.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        AddBtn.setForeground(new java.awt.Color(255, 255, 255));
        AddBtn.setText("Add Task");
        AddBtn.setBorder(null);
        AddBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddBtnActionPerformed(evt);
            }
        });

        DependencyBtn.setBackground(new java.awt.Color(102, 153, 0));
        DependencyBtn.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        DependencyBtn.setForeground(new java.awt.Color(255, 255, 255));
        DependencyBtn.setText("Set Dependencies");
        DependencyBtn.setBorder(null);
        DependencyBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DependencyBtnActionPerformed(evt);
            }
        });

        ViewBtn.setBackground(new java.awt.Color(102, 153, 0));
        ViewBtn.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        ViewBtn.setForeground(new java.awt.Color(255, 255, 255));
        ViewBtn.setText("View Task");
        ViewBtn.setBorder(null);
        ViewBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ViewBtnActionPerformed(evt);
            }
        });

        ScheduleBtn.setBackground(new java.awt.Color(102, 153, 0));
        ScheduleBtn.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        ScheduleBtn.setForeground(new java.awt.Color(255, 255, 255));
        ScheduleBtn.setText("Generate Schedule");
        ScheduleBtn.setBorder(null);
        ScheduleBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ScheduleBtnActionPerformed(evt);
            }
        });

        ExitBtn.setBackground(new java.awt.Color(102, 153, 0));
        ExitBtn.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        ExitBtn.setForeground(new java.awt.Color(255, 255, 255));
        ExitBtn.setText("Exit");
        ExitBtn.setBorder(null);
        ExitBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExitBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(icon, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(DependencyBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(AddBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(ViewBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(ExitBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(ScheduleBtn, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 141, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(icon, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 40, Short.MAX_VALUE)
                .addComponent(AddBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(DependencyBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ViewBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ScheduleBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ExitBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        getContentPane().add(jPanel1, java.awt.BorderLayout.LINE_START);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(new java.awt.CardLayout());

        AddPanel.setBackground(new java.awt.Color(255, 255, 255));

        jLabel4.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel4.setText("Task Name: ");

        jLabel5.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel5.setText("Sub-task Name:");

        TaskNameField.setBackground(new java.awt.Color(153, 204, 0));
        TaskNameField.setText(" ");
        TaskNameField.setBorder(null);
        TaskNameField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TaskNameFieldActionPerformed(evt);
            }
        });

        SubNameField.setBackground(new java.awt.Color(153, 204, 0));
        SubNameField.setText(" ");
        SubNameField.setBorder(null);
        SubNameField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SubNameFieldActionPerformed(evt);
            }
        });

        AddSubBtn.setBackground(new java.awt.Color(102, 153, 0));
        AddSubBtn.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        AddSubBtn.setForeground(new java.awt.Color(255, 255, 255));
        AddSubBtn.setText("Add sub-task");
        AddSubBtn.setBorder(null);
        AddSubBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddSubBtnActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(153, 204, 0));
        jLabel1.setText("SUB-TASK LIST");

        jList1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 153, 0)));
        jList1.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jList1.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane1.setViewportView(jList1);

        SaveTaskBtn.setBackground(new java.awt.Color(102, 153, 0));
        SaveTaskBtn.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        SaveTaskBtn.setForeground(new java.awt.Color(255, 255, 255));
        SaveTaskBtn.setText("Save Task");
        SaveTaskBtn.setBorder(null);
        SaveTaskBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SaveTaskBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout AddPanelLayout = new javax.swing.GroupLayout(AddPanel);
        AddPanel.setLayout(AddPanelLayout);
        AddPanelLayout.setHorizontalGroup(
            AddPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(AddPanelLayout.createSequentialGroup()
                .addGroup(AddPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(AddPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, AddPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(SaveTaskBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, AddPanelLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(AddPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(AddPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(AddSubBtn, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 143, Short.MAX_VALUE)
                            .addComponent(SubNameField)
                            .addComponent(TaskNameField))))
                .addContainerGap())
            .addGroup(AddPanelLayout.createSequentialGroup()
                .addGap(78, 78, 78)
                .addComponent(jLabel1)
                .addContainerGap(85, Short.MAX_VALUE))
        );
        AddPanelLayout.setVerticalGroup(
            AddPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(AddPanelLayout.createSequentialGroup()
                .addGap(9, 9, 9)
                .addGroup(AddPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TaskNameField, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(AddPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(SubNameField, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(AddSubBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(SaveTaskBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jPanel2.add(AddPanel, "card2");

        DependencyPanel.setBackground(new java.awt.Color(255, 255, 255));
        DependencyPanel.setLayout(new java.awt.CardLayout());

        ChooseDependencyPanel.setBackground(new java.awt.Color(255, 255, 255));

        TaskDependencyBtn.setBackground(new java.awt.Color(102, 153, 0));
        TaskDependencyBtn.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        TaskDependencyBtn.setForeground(new java.awt.Color(255, 255, 255));
        TaskDependencyBtn.setText("Task Dependencies");
        TaskDependencyBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TaskDependencyBtnActionPerformed(evt);
            }
        });

        SubtaskDependencyBtn.setBackground(new java.awt.Color(102, 153, 0));
        SubtaskDependencyBtn.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        SubtaskDependencyBtn.setForeground(new java.awt.Color(255, 255, 255));
        SubtaskDependencyBtn.setText("Sub-task Dependencies");
        SubtaskDependencyBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SubtaskDependencyBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout ChooseDependencyPanelLayout = new javax.swing.GroupLayout(ChooseDependencyPanel);
        ChooseDependencyPanel.setLayout(ChooseDependencyPanelLayout);
        ChooseDependencyPanelLayout.setHorizontalGroup(
            ChooseDependencyPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ChooseDependencyPanelLayout.createSequentialGroup()
                .addContainerGap(42, Short.MAX_VALUE)
                .addGroup(ChooseDependencyPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(TaskDependencyBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(SubtaskDependencyBtn, javax.swing.GroupLayout.DEFAULT_SIZE, 209, Short.MAX_VALUE))
                .addGap(37, 37, 37))
        );
        ChooseDependencyPanelLayout.setVerticalGroup(
            ChooseDependencyPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ChooseDependencyPanelLayout.createSequentialGroup()
                .addGap(134, 134, 134)
                .addComponent(TaskDependencyBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(SubtaskDependencyBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(137, Short.MAX_VALUE))
        );

        DependencyPanel.add(ChooseDependencyPanel, "card2");

        TaskDependencyPanel.setBackground(new java.awt.Color(255, 255, 255));

        TaskBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        TaskBox1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 153, 0)));
        TaskBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TaskBox1ActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel2.setText("Depends on");

        TaskBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        TaskBox2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 153, 0)));
        TaskBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TaskBox2ActionPerformed(evt);
            }
        });

        AddTaskDependencyBtn.setBackground(new java.awt.Color(102, 153, 0));
        AddTaskDependencyBtn.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        AddTaskDependencyBtn.setForeground(new java.awt.Color(255, 255, 255));
        AddTaskDependencyBtn.setText("Add Dependency");
        AddTaskDependencyBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddTaskDependencyBtnActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(153, 204, 0));
        jLabel3.setText("Task Dependency List");

        jList2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 153, 0)));
        jList2.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane2.setViewportView(jList2);

        DeleteTaskDependencyBtn.setBackground(new java.awt.Color(102, 153, 0));
        DeleteTaskDependencyBtn.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        DeleteTaskDependencyBtn.setForeground(new java.awt.Color(255, 255, 255));
        DeleteTaskDependencyBtn.setText("Delete Dependency");
        DeleteTaskDependencyBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteTaskDependencyBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout TaskDependencyPanelLayout = new javax.swing.GroupLayout(TaskDependencyPanel);
        TaskDependencyPanel.setLayout(TaskDependencyPanelLayout);
        TaskDependencyPanelLayout.setHorizontalGroup(
            TaskDependencyPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, TaskDependencyPanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(52, 52, 52))
            .addGroup(TaskDependencyPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(TaskDependencyPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(AddTaskDependencyBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(TaskDependencyPanelLayout.createSequentialGroup()
                        .addComponent(TaskBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 9, Short.MAX_VALUE)
                        .addComponent(TaskBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(DeleteTaskDependencyBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        TaskDependencyPanelLayout.setVerticalGroup(
            TaskDependencyPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TaskDependencyPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(TaskDependencyPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TaskBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(TaskBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(AddTaskDependencyBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 162, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(DeleteTaskDependencyBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        DependencyPanel.add(TaskDependencyPanel, "card3");

        SubtaskDependencyPanel.setBackground(new java.awt.Color(255, 255, 255));

        jLabel6.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel6.setText("Depends on");

        PickTaskBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        PickTaskBox.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 153, 0)));
        PickTaskBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PickTaskBoxActionPerformed(evt);
            }
        });

        SubtaskBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        SubtaskBox2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 153, 0)));
        SubtaskBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SubtaskBox2ActionPerformed(evt);
            }
        });

        SubtaskBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        SubtaskBox1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 153, 0)));
        SubtaskBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SubtaskBox1ActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(153, 204, 0));
        jLabel7.setText("Sub-task Dependencies List");

        jList3.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane3.setViewportView(jList3);

        AddSubtaskDependencyBtn.setBackground(new java.awt.Color(102, 153, 0));
        AddSubtaskDependencyBtn.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        AddSubtaskDependencyBtn.setForeground(new java.awt.Color(255, 255, 255));
        AddSubtaskDependencyBtn.setText("Add sub-task dependency");
        AddSubtaskDependencyBtn.setBorder(null);
        AddSubtaskDependencyBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddSubtaskDependencyBtnActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel8.setText("Pick a task:");

        DeleteSubtaskDependencyBtn.setBackground(new java.awt.Color(102, 153, 0));
        DeleteSubtaskDependencyBtn.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        DeleteSubtaskDependencyBtn.setForeground(new java.awt.Color(255, 255, 255));
        DeleteSubtaskDependencyBtn.setText("Delete sub-task dependency");
        DeleteSubtaskDependencyBtn.setBorder(null);
        DeleteSubtaskDependencyBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteSubtaskDependencyBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout SubtaskDependencyPanelLayout = new javax.swing.GroupLayout(SubtaskDependencyPanel);
        SubtaskDependencyPanel.setLayout(SubtaskDependencyPanelLayout);
        SubtaskDependencyPanelLayout.setHorizontalGroup(
            SubtaskDependencyPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SubtaskDependencyPanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel7)
                .addGap(36, 36, 36))
            .addGroup(SubtaskDependencyPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(SubtaskDependencyPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(SubtaskDependencyPanelLayout.createSequentialGroup()
                        .addGroup(SubtaskDependencyPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(SubtaskDependencyPanelLayout.createSequentialGroup()
                                .addComponent(SubtaskBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(SubtaskBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(DeleteSubtaskDependencyBtn, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jScrollPane3)
                            .addComponent(AddSubtaskDependencyBtn, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, SubtaskDependencyPanelLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(PickTaskBox, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(19, 19, 19))))
        );
        SubtaskDependencyPanelLayout.setVerticalGroup(
            SubtaskDependencyPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SubtaskDependencyPanelLayout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(SubtaskDependencyPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(PickTaskBox, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addGap(30, 30, 30)
                .addGroup(SubtaskDependencyPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(SubtaskBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(SubtaskBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(AddSubtaskDependencyBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 99, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(DeleteSubtaskDependencyBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        DependencyPanel.add(SubtaskDependencyPanel, "card4");

        jPanel2.add(DependencyPanel, "card3");

        ViewPanel.setBackground(new java.awt.Color(255, 255, 255));
        ViewPanel.setLayout(new java.awt.CardLayout());

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        jLabel9.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(153, 204, 0));
        jLabel9.setText("Task List");

        jList4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 153, 0)));
        jList4.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane4.setViewportView(jList4);

        EditBtn.setBackground(new java.awt.Color(102, 153, 0));
        EditBtn.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        EditBtn.setForeground(new java.awt.Color(255, 255, 255));
        EditBtn.setText("Edit");
        EditBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EditBtnActionPerformed(evt);
            }
        });

        DeleteBtn.setBackground(new java.awt.Color(102, 153, 0));
        DeleteBtn.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        DeleteBtn.setForeground(new java.awt.Color(255, 255, 255));
        DeleteBtn.setText("Delete");
        DeleteBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap(16, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 256, Short.MAX_VALUE)
                    .addComponent(DeleteBtn, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(EditBtn, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(16, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel9)
                .addGap(106, 106, 106))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap(34, Short.MAX_VALUE)
                .addComponent(jLabel9)
                .addGap(18, 18, 18)
                .addComponent(EditBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(DeleteBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12))
        );

        ViewPanel.add(jPanel3, "card2");

        EditPanel.setBackground(new java.awt.Color(255, 255, 255));

        jLabel10.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel10.setText("Task Name:");

        jLabel11.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel11.setText("Sub-task Name:");

        EditTaskField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EditTaskFieldActionPerformed(evt);
            }
        });

        EditSubtaskField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EditSubtaskFieldActionPerformed(evt);
            }
        });

        EditAddSubBtn.setBackground(new java.awt.Color(102, 153, 0));
        EditAddSubBtn.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        EditAddSubBtn.setForeground(new java.awt.Color(255, 255, 255));
        EditAddSubBtn.setText("Add Sub-task");
        EditAddSubBtn.setBorder(null);
        EditAddSubBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EditAddSubBtnActionPerformed(evt);
            }
        });

        jLabel12.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(153, 204, 0));
        jLabel12.setText("Sub-task List");

        jList5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 153, 0)));
        jList5.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane5.setViewportView(jList5);

        EditDeleteSubBtn.setBackground(new java.awt.Color(102, 153, 0));
        EditDeleteSubBtn.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        EditDeleteSubBtn.setForeground(new java.awt.Color(255, 255, 255));
        EditDeleteSubBtn.setText("Delete Sub-task");
        EditDeleteSubBtn.setBorder(null);
        EditDeleteSubBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EditDeleteSubBtnActionPerformed(evt);
            }
        });

        EditSaveTaskBtn.setBackground(new java.awt.Color(102, 153, 0));
        EditSaveTaskBtn.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        EditSaveTaskBtn.setForeground(new java.awt.Color(255, 255, 255));
        EditSaveTaskBtn.setText("Save Task");
        EditSaveTaskBtn.setBorder(null);
        EditSaveTaskBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EditSaveTaskBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout EditPanelLayout = new javax.swing.GroupLayout(EditPanel);
        EditPanel.setLayout(EditPanelLayout);
        EditPanelLayout.setHorizontalGroup(
            EditPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(EditPanelLayout.createSequentialGroup()
                .addGroup(EditPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(EditPanelLayout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addGroup(EditPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel10)
                            .addComponent(jLabel11))
                        .addGap(44, 44, 44)
                        .addGroup(EditPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(EditTaskField)
                            .addComponent(EditSubtaskField)
                            .addComponent(EditAddSubBtn, javax.swing.GroupLayout.DEFAULT_SIZE, 131, Short.MAX_VALUE)))
                    .addGroup(EditPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane5))
                    .addGroup(EditPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(EditPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(EditDeleteSubBtn, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(EditSaveTaskBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap())
            .addGroup(EditPanelLayout.createSequentialGroup()
                .addGap(92, 92, 92)
                .addComponent(jLabel12)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        EditPanelLayout.setVerticalGroup(
            EditPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(EditPanelLayout.createSequentialGroup()
                .addGap(8, 8, 8)
                .addGroup(EditPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(EditTaskField, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(EditPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(EditSubtaskField, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(EditAddSubBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addComponent(jLabel12)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 99, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(EditDeleteSubBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(EditSaveTaskBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        ViewPanel.add(EditPanel, "card3");

        jPanel2.add(ViewPanel, "card4");

        jLabel13.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(153, 204, 0));
        jLabel13.setText("Final Schedule");

        ScheduleArea.setColumns(20);
        ScheduleArea.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        ScheduleArea.setRows(5);
        ScheduleArea.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 153, 0)));
        jScrollPane6.setViewportView(ScheduleArea);

        javax.swing.GroupLayout SchedulePanelLayout = new javax.swing.GroupLayout(SchedulePanel);
        SchedulePanel.setLayout(SchedulePanelLayout);
        SchedulePanelLayout.setHorizontalGroup(
            SchedulePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SchedulePanelLayout.createSequentialGroup()
                .addGroup(SchedulePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(SchedulePanelLayout.createSequentialGroup()
                        .addGap(86, 86, 86)
                        .addComponent(jLabel13))
                    .addGroup(SchedulePanelLayout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(24, Short.MAX_VALUE))
        );
        SchedulePanelLayout.setVerticalGroup(
            SchedulePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SchedulePanelLayout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(jLabel13)
                .addGap(26, 26, 26)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 258, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(22, Short.MAX_VALUE))
        );

        jPanel2.add(SchedulePanel, "card5");

        getContentPane().add(jPanel2, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void AddBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddBtnActionPerformed
        // clears the add-task form and switches to add panel
        addSubModel.clear();
        TaskNameField.setText("");
        SubNameField.setText("");
        showCard(jPanel2, "card2");
    }//GEN-LAST:event_AddBtnActionPerformed

    private void DependencyBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DependencyBtnActionPerformed
        // refreshes all combo boxes and dep lists, then shows dependency choose screen
        refreshTaskBoxes();
        refreshTaskDepList();
        refreshSubDepList();
        showCard(jPanel2, "card3");
        showCard(DependencyPanel, "card2");
    }//GEN-LAST:event_DependencyBtnActionPerformed

    private void ViewBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ViewBtnActionPerformed
        // reloads task list and shows view panel
        refreshViewList();
        showCard(jPanel2, "card4");
        showCard(ViewPanel, "card2");
    }//GEN-LAST:event_ViewBtnActionPerformed

    private void ScheduleBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ScheduleBtnActionPerformed
    // runs kahn's algorithm and displays ordered schedule; shows error on circular dep
    if (manager.size() == 0) {
        JOptionPane.showMessageDialog(this,
            "No tasks added yet. Please add tasks first.",
            "Empty", JOptionPane.WARNING_MESSAGE);
        return;
    }
    try {
        java.util.List<String> order = KahnsAlgorithm.generateSchedule(graph);
        StringBuilder sb = new StringBuilder();
        sb.append("EVENT: ").append(eventTitle).append("\n\n");
        int step = 1;
        for (String name : order) {
            Task t = manager.getTask(name);
            sb.append("Step ").append(step++).append(": ").append(name).append("\n");
            if (t != null) {
                java.util.List<String> orderedSubs = getOrderedSubtasks(name, t.getSubtasks());
                for (String sub : orderedSubs) {
                    sb.append("   - ").append(sub).append("\n");
                }
            }
            sb.append("\n");
        }
        sb.append("Total tasks scheduled: ").append(order.size());
        ScheduleArea.setText(sb.toString());
        ScheduleArea.setCaretPosition(0);
        
      // display which level the cycle was detected at   
    } catch (RuntimeException e) {
        String msg = e.getMessage();
        String type = msg != null && msg.contains("subtasks of task")
            ? "SUBTASK-LEVEL CIRCULAR DEPENDENCY"
            : "TASK-LEVEL CIRCULAR DEPENDENCY";
        ScheduleArea.setText("ERROR: " + type + "\n\n" + msg
            + "\n\nFix the circular dependency\n and try again."
            + "\n\nHow to fix:"
            + "\nGo to Set Dependencies"
            + "\nDelete the dependency causing\n the cycle.");
    }
    showCard(jPanel2, "card5");
    }//GEN-LAST:event_ScheduleBtnActionPerformed

    private void ExitBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExitBtnActionPerformed
        // confirms before exiting the application    
        int choice = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to exit?",
            "Exit", JOptionPane.YES_NO_OPTION);
        if (choice == JOptionPane.YES_OPTION) System.exit(0);
    }//GEN-LAST:event_ExitBtnActionPerformed

    private void AddSubBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddSubBtnActionPerformed
        // adds typed subtask to the temp list; clears field after
        String sub = SubNameField.getText().trim();
        if (sub.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "Please type a sub-task name before adding.",
                "Empty Sub-task", JOptionPane.WARNING_MESSAGE);
            return;
        }
        addSubModel.addElement(sub);
        SubNameField.setText("");
        SubNameField.requestFocus();
    }//GEN-LAST:event_AddSubBtnActionPerformed

    private void TaskNameFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TaskNameFieldActionPerformed
        SubNameField.requestFocus();  // enter in task name field moves focus to subtask field
    }//GEN-LAST:event_TaskNameFieldActionPerformed

    private void SubNameFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SubNameFieldActionPerformed
        AddSubBtnActionPerformed(evt); // enter in subtask field triggers add subtask
    }//GEN-LAST:event_SubNameFieldActionPerformed

    private void SaveTaskBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SaveTaskBtnActionPerformed
        // validates input then saves task + subtasks to manager and graph
        String name = TaskNameField.getText().trim();
        if (name.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a task name.", "Missing Name", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (addSubModel.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please add at least one sub-task before saving.", "No Sub-tasks", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (manager.hasTask(name)) {
            JOptionPane.showMessageDialog(this, "A task named \"" + name + "\" already exists.", "Duplicate", JOptionPane.WARNING_MESSAGE);
            return;
        }
        manager.addTask(name);
        graph.addTaskNode(name);
        Task t = manager.getTask(name);
        for (int i = 0; i < addSubModel.size(); i++) t.addSubtask(addSubModel.get(i));
 
        addSubModel.clear();
        TaskNameField.setText("");
        refreshTaskBoxes();
        JOptionPane.showMessageDialog(this, "Task \"" + name + "\" saved!", "Saved", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_SaveTaskBtnActionPerformed

    private void TaskDependencyBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TaskDependencyBtnActionPerformed
        // refreshes combo boxes and dep list, then shows task dependency panel
        refreshTaskBoxes();
        refreshTaskDepList();
        showCard(DependencyPanel, "card3");
    }//GEN-LAST:event_TaskDependencyBtnActionPerformed

    private void SubtaskDependencyBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SubtaskDependencyBtnActionPerformed
         // refreshes combo boxes and dep list, then shows subtask dependency panel
        refreshTaskBoxes();
        refreshSubDepList();
        showCard(DependencyPanel, "card4");
    }//GEN-LAST:event_SubtaskDependencyBtnActionPerformed

    private void AddTaskDependencyBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddTaskDependencyBtnActionPerformed
        // adds a directed task dependency; rejects self-deps and duplicates
        String task      = (String) TaskBox1.getSelectedItem();
        String dependsOn = (String) TaskBox2.getSelectedItem();
        if (task == null || dependsOn == null) {
            JOptionPane.showMessageDialog(this, "Please add at least two tasks first.", "Not Enough Tasks", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (task.equals(dependsOn)) {
            JOptionPane.showMessageDialog(this, "A task cannot depend on itself.", "Invalid", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (graph.addTaskDependency(task, dependsOn)) {
            refreshTaskDepList();
            JOptionPane.showMessageDialog(this,
                "\"" + task + "\" now depends on \"" + dependsOn + "\".",
                "Dependency Added", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "That dependency already exists.", "Duplicate", JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_AddTaskDependencyBtnActionPerformed

    private void TaskBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TaskBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TaskBox1ActionPerformed

    private void DeleteTaskDependencyBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteTaskDependencyBtnActionPerformed
        // deletes selected task dependency after confirmation
        int idx = jList2.getSelectedIndex();
        if (idx < 0) {
            JOptionPane.showMessageDialog(this, "Please select a dependency to delete.", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }
        java.util.List<String> raw = graph.getTaskDepRawList();
        if (idx >= raw.size()) return;
        int confirm = JOptionPane.showConfirmDialog(this,
            "Delete: " + taskDepModel.get(idx) + "?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            graph.deleteTaskDependencyByKey(raw.get(idx));
            refreshTaskDepList();
        }
    }//GEN-LAST:event_DeleteTaskDependencyBtnActionPerformed

    private void TaskBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TaskBox2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TaskBox2ActionPerformed

    private void PickTaskBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PickTaskBoxActionPerformed
    // populates subtask combo boxes based on selected parent task
        SubtaskBox1.removeAllItems();
        SubtaskBox2.removeAllItems();
        String picked = (String) PickTaskBox.getSelectedItem();
        if (picked == null) return;
        Task pickedTask = manager.getTask(picked);
        if (pickedTask != null) {
            for (String sub : pickedTask.getSubtasks()) {
                SubtaskBox1.addItem(sub);
                SubtaskBox2.addItem(sub + " [" + picked + "]");  // keep the tag
            }
        }   
    }//GEN-LAST:event_PickTaskBoxActionPerformed

    private void SubtaskBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SubtaskBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SubtaskBox1ActionPerformed

    private void SubtaskBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SubtaskBox2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SubtaskBox2ActionPerformed

    private void AddSubtaskDependencyBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddSubtaskDependencyBtnActionPerformed
    // adds a subtask dependency; parses "subtask [parent]" format; rejects self-deps and duplicates
    String parentA = (String) PickTaskBox.getSelectedItem();
    String subA    = (String) SubtaskBox1.getSelectedItem();
    String subBRaw = (String) SubtaskBox2.getSelectedItem();

    if (parentA == null || subA == null || subBRaw == null) {
        JOptionPane.showMessageDialog(this, "Please pick a task and select sub-tasks.", "Incomplete", JOptionPane.WARNING_MESSAGE);
        return;
    }

    // extract subtask name and parent from "subtask [ParentTask]"
    int bracket = subBRaw.lastIndexOf(" [");
    if (bracket < 0) {
        JOptionPane.showMessageDialog(this, "Please pick a task first.", "Incomplete", JOptionPane.WARNING_MESSAGE);
        return;
    }
    String subB    = subBRaw.substring(0, bracket);
    String parentB = subBRaw.substring(bracket + 2, subBRaw.length() - 1);

    if (subA.equals(subB)) {
        JOptionPane.showMessageDialog(this, "A sub-task cannot depend on itself.", "Invalid", JOptionPane.WARNING_MESSAGE);
        return;
    }

    if (graph.addSubtaskDependency(parentA, subA, parentB, subB)) {
        refreshSubDepList();
        JOptionPane.showMessageDialog(this,
            "\"" + subA + "\" now depends on \"" + subB + "\".",
            "Added", JOptionPane.INFORMATION_MESSAGE);
    } else {
        JOptionPane.showMessageDialog(this, "That dependency already exists.", "Duplicate", JOptionPane.WARNING_MESSAGE);
    }

    }//GEN-LAST:event_AddSubtaskDependencyBtnActionPerformed

    private void DeleteSubtaskDependencyBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteSubtaskDependencyBtnActionPerformed
        // deletes selected subtask dependency after confirmation
        int idx = jList3.getSelectedIndex();
        if (idx < 0) {
            JOptionPane.showMessageDialog(this, "Please select a dependency to delete.", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }
        java.util.List<String> raw = graph.getSubtaskDepRawList();
        if (idx >= raw.size()) return;
        int confirm = JOptionPane.showConfirmDialog(this,
            "Delete: " + subDepModel.get(idx) + "?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            graph.deleteSubtaskDependencyByKey(raw.get(idx));
            refreshSubDepList();
        }
    }//GEN-LAST:event_DeleteSubtaskDependencyBtnActionPerformed

    private void EditBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EditBtnActionPerformed
         // loads selected task into edit panel; flips to edit card
        String selected = jList4.getSelectedValue();
        if (selected == null) {
            JOptionPane.showMessageDialog(this, "Please select a task to edit.", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }
        editingTask = extractName(selected);
        Task t = manager.getTask(editingTask);
        if (t == null) return;
 
        EditTaskField.setText(t.getName());
        editSubModel.clear();
        for (String sub : t.getSubtasks()) editSubModel.addElement(sub);
        EditSubtaskField.setText("");
 
        showCard(ViewPanel, "card3");  
    }//GEN-LAST:event_EditBtnActionPerformed

    private void DeleteBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteBtnActionPerformed
        // deletes selected task and removes all related graph deps; refreshes all lists

        String selected = jList4.getSelectedValue();
        if (selected == null) {
            JOptionPane.showMessageDialog(this, "Please select a task to delete.", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String name = extractName(selected);
        int confirm = JOptionPane.showConfirmDialog(this,
            "Delete task \"" + name + "\" and all its dependencies?",
            "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            manager.deleteTask(name);
            graph.removeTaskNode(name);
            refreshViewList();
            refreshTaskBoxes();
            refreshTaskDepList();
            refreshSubDepList();
            JOptionPane.showMessageDialog(this, "Task \"" + name + "\" deleted.", "Deleted", JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_DeleteBtnActionPerformed

    private void EditTaskFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EditTaskFieldActionPerformed
        EditSubtaskField.requestFocus(); // enter in task name field moves focus to subtask field
    }//GEN-LAST:event_EditTaskFieldActionPerformed

    private void EditSubtaskFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EditSubtaskFieldActionPerformed
        EditAddSubBtnActionPerformed(evt); // enter in subtask field triggers add subtask
    }//GEN-LAST:event_EditSubtaskFieldActionPerformed

    private void EditAddSubBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EditAddSubBtnActionPerformed
         // appends typed subtask to edit list
        String sub = EditSubtaskField.getText().trim();
        if (sub.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please type a sub-task name.", "Empty", JOptionPane.WARNING_MESSAGE);
            return;
        }
        editSubModel.addElement(sub);
        EditSubtaskField.setText("");
        EditSubtaskField.requestFocus();
    }//GEN-LAST:event_EditAddSubBtnActionPerformed

    private void EditDeleteSubBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EditDeleteSubBtnActionPerformed
        // removes selected subtask from edit list
        int idx = jList5.getSelectedIndex();
        if (idx < 0) {
            JOptionPane.showMessageDialog(this, "Please select a sub-task to delete.", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }
        editSubModel.remove(idx);
    }//GEN-LAST:event_EditDeleteSubBtnActionPerformed

    private void EditSaveTaskBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EditSaveTaskBtnActionPerformed
       // saves edited task; rebuilds graph node if name changed; returns to task list
        String newName = EditTaskField.getText().trim();
        if (newName.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Task name cannot be empty.", "Missing Name", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (editSubModel.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Task must have at least one sub-task.", "No Sub-tasks", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (!newName.equals(editingTask) && manager.hasTask(newName)) {
            JOptionPane.showMessageDialog(this, "A task named \"" + newName + "\" already exists.", "Duplicate", JOptionPane.WARNING_MESSAGE);
            return;
        }
 
        // delete old, recreate with new name and subtasks
        manager.deleteTask(editingTask);
        graph.removeTaskNode(editingTask);
        manager.addTask(newName);
        graph.addTaskNode(newName);
        Task updated = manager.getTask(newName);
        for (int i = 0; i < editSubModel.size(); i++) updated.addSubtask(editSubModel.get(i));
 
        JOptionPane.showMessageDialog(this, "Task \"" + newName + "\" saved!", "Saved", JOptionPane.INFORMATION_MESSAGE);
        refreshViewList();
        refreshTaskBoxes();
        showCard(ViewPanel, "card2"); 
    }                                               

     // switches a CardLayout panel to the named card
    private void showCard(javax.swing.JPanel container, String card) {
        ((CardLayout) container.getLayout()).show(container, card);
    }
 
    // repopulates all three task combo boxes with current task names
    private void refreshTaskBoxes() {
        TaskBox1.removeAllItems();
        TaskBox2.removeAllItems();
        PickTaskBox.removeAllItems();
        for (Task t : manager.getAllTasks()) {
            TaskBox1.addItem(t.getName());
            TaskBox2.addItem(t.getName());
            PickTaskBox.addItem(t.getName());
        }
    }
 
    // reloads task dependency display list
    private void refreshTaskDepList() {
        taskDepModel.clear();
        for (String s : graph.getTaskDepDisplayList()) taskDepModel.addElement(s);
    }
 
    // reloads subtask dependency display list
    private void refreshSubDepList() {
        subDepModel.clear();
        for (String s : graph.getSubtaskDepDisplayList()) subDepModel.addElement(s);
    }
 
     // reloads view task list with name and subtask count
    private void refreshViewList() {
        viewModel.clear();
        for (Task t : manager.getAllTasks()) {
            viewModel.addElement(t.getName() + " (" + t.getSubtasks().size() + " subtask(s))");
        }
    }
 
     // strips " (N subtask(s))" suffix to get the plain task name
    private String extractName(String entry) {
        int idx = entry.indexOf(" (");
        return idx >= 0 ? entry.substring(0, idx) : entry;
    }//GEN-LAST:event_EditSaveTaskBtnActionPerformed


    public static void main(String args[]) {
    try {
        javax.swing.UIManager.setLookAndFeel(
            javax.swing.UIManager.getSystemLookAndFeelClassName()
        );
    } catch (Exception ex) { }

    java.awt.EventQueue.invokeLater(new Runnable() {
        public void run() {
            new FunctionalitiesGUI().setVisible(true);
        }
    });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AddBtn;
    private javax.swing.JPanel AddPanel;
    private javax.swing.JButton AddSubBtn;
    private javax.swing.JButton AddSubtaskDependencyBtn;
    private javax.swing.JButton AddTaskDependencyBtn;
    private javax.swing.JPanel ChooseDependencyPanel;
    private javax.swing.JButton DeleteBtn;
    private javax.swing.JButton DeleteSubtaskDependencyBtn;
    private javax.swing.JButton DeleteTaskDependencyBtn;
    private javax.swing.JButton DependencyBtn;
    private javax.swing.JPanel DependencyPanel;
    private javax.swing.JButton EditAddSubBtn;
    private javax.swing.JButton EditBtn;
    private javax.swing.JButton EditDeleteSubBtn;
    private javax.swing.JPanel EditPanel;
    private javax.swing.JButton EditSaveTaskBtn;
    private javax.swing.JTextField EditSubtaskField;
    private javax.swing.JTextField EditTaskField;
    private javax.swing.JButton ExitBtn;
    private javax.swing.JComboBox<String> PickTaskBox;
    private javax.swing.JButton SaveTaskBtn;
    private javax.swing.JTextArea ScheduleArea;
    private javax.swing.JButton ScheduleBtn;
    private javax.swing.JPanel SchedulePanel;
    private javax.swing.JTextField SubNameField;
    private javax.swing.JComboBox<String> SubtaskBox1;
    private javax.swing.JComboBox<String> SubtaskBox2;
    private javax.swing.JButton SubtaskDependencyBtn;
    private javax.swing.JPanel SubtaskDependencyPanel;
    private javax.swing.JComboBox<String> TaskBox1;
    private javax.swing.JComboBox<String> TaskBox2;
    private javax.swing.JButton TaskDependencyBtn;
    private javax.swing.JPanel TaskDependencyPanel;
    private javax.swing.JTextField TaskNameField;
    private javax.swing.JButton ViewBtn;
    private javax.swing.JPanel ViewPanel;
    private javax.swing.JLabel icon;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JList<String> jList1;
    private javax.swing.JList<String> jList2;
    private javax.swing.JList<String> jList3;
    private javax.swing.JList<String> jList4;
    private javax.swing.JList<String> jList5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    // End of variables declaration//GEN-END:variables
}
