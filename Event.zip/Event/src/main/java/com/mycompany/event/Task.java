/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.event;
import java.util.*;

// represents a single task with a name, category, and list of subtasks
public class Task {
    private String       name;
    private String       category;
    private List<String> subTasks = new ArrayList<>();

    public Task(String name, String category) {
        this.name     = name;
        this.category = category;
    }

    public String getName(){ 
        return name; 
    }
    public void   setName(String n){ 
        this.name = n; 
    }
    public String getCategory(){
        return category; 
    }
    public void   addSubTask(String sub){ 
        subTasks.add(sub); 
    }
    public void   addSubtask(String sub){
        subTasks.add(sub); 
    }
    public void   removeSubTask(int i){
        if (i >= 0 && i < subTasks.size()) subTasks.remove(i); 
    }
    public void   clearSubTasks(){
        subTasks.clear(); 
    }
    public List<String> getSubTasks(){
        return subTasks; 
    }
    public List<String> getSubtasks(){ 
        return subTasks; 
    }  
}
