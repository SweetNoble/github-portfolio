package com.mycompany.event;
import java.util.*;

// topological sort using kahn's algorithm to generate a valid task schedule
public class KahnsAlgorithm {

    public static List<String> generateSchedule(Graph graph){
        Map<String, Integer> inDegree = new HashMap<>(graph.getInDegree()); // copy to avoid mutation
        Queue<String> queue  = new LinkedList<>();
        List<String>  result = new ArrayList<>();

        // start with all nodes that have no dependencies
        for (String t : inDegree.keySet())
            if (inDegree.get(t) == 0) queue.add(t);

        while (!queue.isEmpty()) {
            String cur = queue.poll();
            result.add(cur);
            List<String> neighbors = graph.getAdjList().get(cur);
            if (neighbors != null)
                for (String nb : neighbors) {
                    inDegree.put(nb, inDegree.get(nb) - 1);
                    if (inDegree.get(nb) == 0) queue.add(nb);
                }
        }

        // if not all nodes were processed, a cycle exists
        if (result.size() != inDegree.size()) {
            List<String> cycle = new ArrayList<>();
            for (Map.Entry<String, Integer> e : inDegree.entrySet())
                if (e.getValue() > 0) cycle.add(e.getKey());
            throw new RuntimeException(
                "Circular dependency detected!\nTasks involved: " + String.join(", ", cycle));
        }
        return result;
    }
}