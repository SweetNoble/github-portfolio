/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.event;

public class Main {
    public static void main(String[] args) {
        try {
            // Use system default look and feel instead of Nimbus
            javax.swing.UIManager.setLookAndFeel(
                javax.swing.UIManager.getSystemLookAndFeelClassName()
            );
        } catch (Exception e) { /* use default */ }

        java.awt.EventQueue.invokeLater(() -> new WelcomeGUI().setVisible(true));
    }
}
