package com.mycompany.event;
import java.util.*;

// directed graph for task and subtask dependencies
public class Graph {
    private Map<String, List<String>> adjList     = new HashMap<>();  // adjacency list
    private Map<String, Integer>      inDegree    = new HashMap<>();  // in-degree per node
    private List<String>              taskDepList = new ArrayList<>(); // raw task dep keys
    private List<String>              subDepList  = new ArrayList<>(); // raw subtask dep keys

    public void addTask(String task) {
        adjList.putIfAbsent(task, new ArrayList<>());
        inDegree.putIfAbsent(task, 0);
    }

    public void addTaskNode(String task){
        addTask(task); 
    } 
    public void removeTaskNode(String task){
        removeTask(task); 
    } 

    // adds a directed edge: task depends on dependsOn; returns false if duplicate
    public boolean addTaskDependency(String task, String dependsOn){
        addTask(task); addTask(dependsOn);
        String key = task + "||" + dependsOn;
        if (taskDepList.contains(key)) return false;
        adjList.get(dependsOn).add(task);
        inDegree.put(task, inDegree.get(task) + 1);
        taskDepList.add(key);
        return true;
    }

    // removes a task dependency by its raw key
    public boolean deleteTaskDependencyByKey(String key){
        if (!taskDepList.contains(key)) return false;
        String[] p = key.split("\\|\\|");
        if (p.length != 2) return false;
        adjList.getOrDefault(p[1], new ArrayList<>()).remove(p[0]);
        if (inDegree.containsKey(p[0]))
            inDegree.put(p[0], Math.max(0, inDegree.get(p[0]) - 1));
        taskDepList.remove(key);
        return true;
    }

    // returns display-friendly list: "taskA → taskB"
    public List<String> getTaskDepDisplayList(){
        List<String> out = new ArrayList<>();
        for (String k : taskDepList) {
            String[] p = k.split("\\|\\|");
            if (p.length == 2) out.add(p[0] + "  →  " + p[1]);
        }
        return out;
    }

    public List<String> getTaskDepRawList(){
        return new ArrayList<>(taskDepList); 
    }

    // key format: "parentA::subA||subB [parentB]"
    public boolean addSubtaskDependency(String parentA, String subA,String parentB, String subB){
        String key = parentA + "::" + subA + "||" + subB + " [" + parentB + "]";
        if (subDepList.contains(key)) return false;
        subDepList.add(key);
        return true;
    }

    public boolean deleteSubtaskDependencyByKey(String key){ 
        return subDepList.remove(key); 
    }

    // returns display-friendly subtask deps: "subA → subB [parentB]"
    public List<String> getSubtaskDepDisplayList(){
        List<String> out = new ArrayList<>();
        for (String k : subDepList) {
            int colon = k.indexOf("::");
            int pipe  = k.indexOf("||");
            if (colon > 0 && pipe > colon)
                out.add(k.substring(colon + 2, pipe) + "  →  " + k.substring(pipe + 2));
        }
        return out;
    }

    public List<String> getSubtaskDepRawList(){ 
        return new ArrayList<>(subDepList); 
    }

    // removes a task node and all its associated dependencies
    public void removeTask(String task){
        List<String> neighbors = adjList.remove(task);
        if (neighbors != null)
            for (String n : neighbors)
                if (inDegree.containsKey(n))
                    inDegree.put(n, Math.max(0, inDegree.get(n) - 1));
        inDegree.remove(task);
        for (Map.Entry<String, List<String>> e : adjList.entrySet())
            e.getValue().remove(task);
        taskDepList.removeIf(k -> k.startsWith(task + "||") || k.endsWith("||" + task));
        subDepList .removeIf(k -> k.startsWith(task + "::"));
    }

    public Map<String, List<String>> getAdjList(){
        return adjList; 
    }
    public Map<String, Integer>      getInDegree(){
        return inDegree; 
    }
}